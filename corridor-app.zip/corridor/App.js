// App.js
import React, { useEffect } from 'react';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import AppNavigator from './src/navigation/AppNavigator';
import { listenAuth, fetchUserProfile } from './src/services/authService';
import { listenPendingRequests } from './src/services/connectionService';
import useStore from './src/store/useStore';

export default function App() {
  const setAuthUser    = useStore(s => s.setAuthUser);
  const setUserProfile = useStore(s => s.setUserProfile);
  const setAuthLoading = useStore(s => s.setAuthLoading);
  const setPending     = useStore(s => s.setPendingCount);

  useEffect(() => {
    let unsubRequests = null;

    // Listen to Firebase auth state changes
    const unsubAuth = listenAuth(async (user) => {
      setAuthUser(user);

      if (user) {
        // Fetch the Firestore profile
        const profile = await fetchUserProfile(user.uid);
        setUserProfile(profile);

        // Listen for incoming connection requests (for badge count)
        unsubRequests = listenPendingRequests(user.uid, reqs => {
          setPending(reqs.length);
        });
      } else {
        setUserProfile(null);
        setPending(0);
        if (unsubRequests) { unsubRequests(); unsubRequests = null; }
      }

      setAuthLoading(false);
    });

    return () => {
      unsubAuth();
      if (unsubRequests) unsubRequests();
    };
  }, []);

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <AppNavigator />
    </GestureHandlerRootView>
  );
}
