# Corridor — Setup Guide
## Christ (Deemed to be) University, Ghaziabad

---

## STEP 1 — Install tools on your laptop

1. Download and install **Node.js** from https://nodejs.org (choose LTS version)
2. Install **Expo CLI** by opening terminal and running:
   ```
   npm install -g expo-cli
   ```
3. Install **Expo Go** app on your phone from Play Store or App Store

---

## STEP 2 — Set up Firebase (free)

1. Go to https://console.firebase.google.com
2. Click "Add project" → name it "corridor-christgzb" → Continue
3. Disable Google Analytics (not needed) → Create project

### Enable Authentication
- Left sidebar → Build → Authentication → Get started
- Enable "Email/Password" provider → Save

### Enable Firestore Database
- Left sidebar → Build → Firestore Database → Create database
- Choose "Start in test mode" (we'll add rules later) → Next
- Choose region: "asia-south1 (Mumbai)" → Done

### Enable Storage (for photos)
- Left sidebar → Build → Storage → Get started
- Start in test mode → Next → Done

### Get your config keys
- Click the gear icon ⚙️ → Project Settings
- Scroll to "Your apps" → Click "</>" (Web app)
- Register app name: "corridor" → Register
- **Copy the firebaseConfig object** — you'll paste it in the next step

---

## STEP 3 — Add your Firebase config to the app

Open the file: `src/services/firebase.js`

Replace this section:
```js
const firebaseConfig = {
  apiKey:            "PASTE_YOUR_API_KEY_HERE",
  authDomain:        "PASTE_YOUR_AUTH_DOMAIN_HERE",
  ...
```

With your actual config from Firebase Console. It looks like:
```js
const firebaseConfig = {
  apiKey:            "AIzaSyAbc123...",
  authDomain:        "corridor-christgzb.firebaseapp.com",
  projectId:         "corridor-christgzb",
  storageBucket:     "corridor-christgzb.appspot.com",
  messagingSenderId: "123456789",
  appId:             "1:123456789:web:abc123",
};
```

---

## STEP 4 — Add Firestore security rules

1. Go to Firebase Console → Firestore → Rules tab
2. Delete everything there
3. Copy the contents of `firestore.rules` file and paste it
4. Click "Publish"

---

## STEP 5 — Run the app

Open terminal in the `corridor` folder and run:
```
npm install
npm start
```

This shows a QR code. Open Expo Go on your phone, scan the QR code — the app loads on your phone instantly!

---

## STEP 6 — Test it

1. Register with your @christuniversity.in email
2. Verify email (check inbox)
3. Log in and complete your profile
4. Ask a friend to do the same
5. Send each other connection requests
6. When both accept → chat opens automatically!

---

## Folder structure

```
corridor/
├── App.js                          ← Root entry point
├── package.json                    ← Dependencies
├── babel.config.js
├── firestore.rules                 ← Paste into Firebase Console
└── src/
    ├── screens/
    │   ├── SplashScreen.js         ← Loading screen
    │   ├── LoginScreen.js          ← Login
    │   ├── RegisterScreen.js       ← Sign up
    │   ├── ProfileSetupScreen.js   ← 3-step profile setup
    │   ├── DiscoverScreen.js       ← Browse & connect
    │   ├── RequestsScreen.js       ← Pending requests (with badge)
    │   ├── ChatsScreen.js          ← All chats list
    │   ├── ChatRoomScreen.js       ← Live chat
    │   ├── MyProfileScreen.js      ← Your profile + dark mode toggle
    │   ├── SettingsScreen.js       ← Settings
    │   └── BlockedScreen.js        ← Blocked users list
    ├── services/
    │   ├── firebase.js             ← Firebase init (ADD YOUR CONFIG HERE)
    │   ├── authService.js          ← Register, login, logout
    │   ├── userService.js          ← Profile, photo upload, block/unblock
    │   ├── connectionService.js    ← Send/accept/reject requests
    │   └── chatService.js          ← Real-time messaging
    ├── navigation/
    │   └── AppNavigator.js         ← All screen routing
    ├── store/
    │   └── useStore.js             ← Global state (Zustand)
    └── utils/
        └── theme.js                ← Colors, dark/light mode, tag colors
```

---

## What's built

| Feature | Status |
|---|---|
| College email gate (@christuniversity.in only) | ✅ |
| Register + email verification | ✅ |
| Login / logout | ✅ |
| 3-step profile setup (photos + bio + preferences) | ✅ |
| Cover photo + avatar upload | ✅ |
| Discover feed (all students) | ✅ |
| Filter by year + looking for | ✅ |
| Skip / Connect buttons | ✅ |
| Send connection request | ✅ |
| Pending requests screen with badge | ✅ |
| Accept request → chat auto-created | ✅ |
| Real-time chat (live messages) | ✅ |
| Block / unblock users | ✅ |
| Blocked users list in settings | ✅ |
| Dark mode / light mode toggle | ✅ |
| Firestore security rules | ✅ |

---

## Next things to add (future)

- Push notifications (when you get a request or message)
- Report user feature
- Edit profile after setup
- Group chats / campus announcements
- Profile views counter
- Admin dashboard for college
