// src/services/connectionService.js
import {
  collection, doc, addDoc, updateDoc, deleteDoc,
  query, where, getDocs, getDoc,
  arrayUnion, serverTimestamp, onSnapshot,
} from 'firebase/firestore';
import { db } from './firebase';

const reqCol = collection(db, 'connectionRequests');

// ── Send a connect request ────────────────────────────────
export async function sendConnectionRequest(fromUid, toUid) {
  // Check not already sent
  const existing = await getDocs(
    query(reqCol,
      where('fromUid', '==', fromUid),
      where('toUid',   '==', toUid))
  );
  if (!existing.empty) return; // already sent

  await addDoc(reqCol, {
    fromUid,
    toUid,
    status:    'pending',    // 'pending' | 'accepted' | 'rejected'
    createdAt: serverTimestamp(),
  });
}

// ── Accept a request ──────────────────────────────────────
export async function acceptConnectionRequest(requestId, fromUid, toUid) {
  // Mark accepted
  await updateDoc(doc(db, 'connectionRequests', requestId), {
    status: 'accepted',
    acceptedAt: serverTimestamp(),
  });

  // Add to both users' connections arrays
  await updateDoc(doc(db, 'users', fromUid), {
    connections: arrayUnion(toUid),
  });
  await updateDoc(doc(db, 'users', toUid), {
    connections: arrayUnion(fromUid),
  });

  // Create a chat room between them
  const chatId = [fromUid, toUid].sort().join('_');
  await updateDoc(doc(db, 'chats', chatId), {}).catch(async () => {
    const { setDoc } = await import('firebase/firestore');
    await setDoc(doc(db, 'chats', chatId), {
      participants:   [fromUid, toUid],
      createdAt:      serverTimestamp(),
      lastMessage:    '',
      lastMessageAt:  serverTimestamp(),
    });
  });

  return chatId;
}

// ── Reject a request ──────────────────────────────────────
export async function rejectConnectionRequest(requestId) {
  await deleteDoc(doc(db, 'connectionRequests', requestId));
}

// ── Fetch pending requests sent TO me ────────────────────
export async function fetchPendingRequests(myUid) {
  const snap = await getDocs(
    query(reqCol,
      where('toUid',  '==', myUid),
      where('status', '==', 'pending'))
  );

  const requests = [];
  for (const d of snap.docs) {
    const req  = d.data();
    const user = await getDoc(doc(db, 'users', req.fromUid));
    if (user.exists()) {
      requests.push({ requestId: d.id, ...req, fromUser: user.data() });
    }
  }
  return requests;
}

// ── Real-time listener for pending requests ───────────────
export function listenPendingRequests(myUid, callback) {
  return onSnapshot(
    query(reqCol,
      where('toUid',  '==', myUid),
      where('status', '==', 'pending')),
    async (snap) => {
      const requests = [];
      for (const d of snap.docs) {
        const req  = d.data();
        const user = await getDoc(doc(db, 'users', req.fromUid));
        if (user.exists()) {
          requests.push({ requestId: d.id, ...req, fromUser: user.data() });
        }
      }
      callback(requests);
    }
  );
}
