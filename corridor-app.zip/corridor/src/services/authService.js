// src/services/authService.js
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  sendEmailVerification,
  sendPasswordResetEmail,
  onAuthStateChanged,
} from 'firebase/auth';
import { doc, setDoc, getDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db } from './firebase';

// Only allow Christ University Ghaziabad emails
const ALLOWED_DOMAIN = 'christuniversity.in';

export function isCollegeEmail(email) {
  return email.trim().toLowerCase().endsWith(`@${ALLOWED_DOMAIN}`);
}

// ── Register ─────────────────────────────────────────────
export async function registerUser(email, password, basicInfo) {
  const cleanEmail = email.trim().toLowerCase();

  if (!isCollegeEmail(cleanEmail)) {
    throw new Error('Only @christuniversity.in email addresses are allowed.');
  }

  const cred = await createUserWithEmailAndPassword(auth, cleanEmail, password);
  await sendEmailVerification(cred.user);

  // Create user document in Firestore
  await setDoc(doc(db, 'users', cred.user.uid), {
    uid:          cred.user.uid,
    email:        cleanEmail,
    name:         basicInfo.name || '',
    year:         basicInfo.year || '',
    department:   basicInfo.department || '',
    bio:          '',
    photoURL:     '',
    coverURL:     '',
    lookingFor:   [],          // e.g. ['Make friends', 'Project partner']
    interests:    [],
    openTo:       ['Everyone'],
    blockedUsers: [],
    connections:  [],
    createdAt:    serverTimestamp(),
    profileDone:  false,       // false until they complete setup
  });

  return cred.user;
}

// ── Login ─────────────────────────────────────────────────
export async function loginUser(email, password) {
  const cleanEmail = email.trim().toLowerCase();
  if (!isCollegeEmail(cleanEmail)) {
    throw new Error('Only @christuniversity.in email addresses are allowed.');
  }
  const cred = await signInWithEmailAndPassword(auth, cleanEmail, password);
  return cred.user;
}

// ── Logout ────────────────────────────────────────────────
export async function logoutUser() {
  await signOut(auth);
}

// ── Password reset ────────────────────────────────────────
export async function resetPassword(email) {
  await sendPasswordResetEmail(auth, email.trim().toLowerCase());
}

// ── Auth state listener ───────────────────────────────────
export function listenAuth(callback) {
  return onAuthStateChanged(auth, callback);
}

// ── Fetch user profile ────────────────────────────────────
export async function fetchUserProfile(uid) {
  const snap = await getDoc(doc(db, 'users', uid));
  return snap.exists() ? snap.data() : null;
}
