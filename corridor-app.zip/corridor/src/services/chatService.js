// src/services/chatService.js
import {
  collection, doc, addDoc, updateDoc,
  query, orderBy, onSnapshot, getDocs,
  serverTimestamp, getDoc, where,
} from 'firebase/firestore';
import { db } from './firebase';

// Chat ID is always the two UIDs sorted and joined, so it's consistent
export function getChatId(uid1, uid2) {
  return [uid1, uid2].sort().join('_');
}

// ── Send a message ─────────────────────────────────────────
export async function sendMessage(chatId, senderUid, text) {
  const msgRef = collection(db, 'chats', chatId, 'messages');

  await addDoc(msgRef, {
    senderUid,
    text:      text.trim(),
    createdAt: serverTimestamp(),
    readBy:    [senderUid],
  });

  // Update last message on chat doc
  await updateDoc(doc(db, 'chats', chatId), {
    lastMessage:   text.trim(),
    lastMessageAt: serverTimestamp(),
    lastSenderUid: senderUid,
  });
}

// ── Real-time listener for messages ───────────────────────
export function listenMessages(chatId, callback) {
  const msgRef = collection(db, 'chats', chatId, 'messages');
  return onSnapshot(
    query(msgRef, orderBy('createdAt', 'asc')),
    snap => {
      const msgs = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      callback(msgs);
    }
  );
}

// ── Fetch all chats for a user ─────────────────────────────
export function listenUserChats(myUid, callback) {
  const chatsRef = collection(db, 'chats');
  return onSnapshot(
    query(chatsRef, where('participants', 'array-contains', myUid)),
    async snap => {
      const chats = [];
      for (const d of snap.docs) {
        const chat = d.data();
        // Get the other participant's profile
        const otherUid = chat.participants.find(u => u !== myUid);
        const userSnap = await getDoc(doc(db, 'users', otherUid));
        if (userSnap.exists()) {
          chats.push({
            chatId:    d.id,
            otherUser: userSnap.data(),
            ...chat,
          });
        }
      }
      // Sort by last message time
      chats.sort((a, b) => {
        const ta = a.lastMessageAt?.toMillis?.() || 0;
        const tb = b.lastMessageAt?.toMillis?.() || 0;
        return tb - ta;
      });
      callback(chats);
    }
  );
}

// ── Mark messages as read ─────────────────────────────────
export async function markMessagesRead(chatId, myUid) {
  const msgRef = collection(db, 'chats', chatId, 'messages');
  const snap   = await getDocs(query(msgRef));
  const batch  = [];
  snap.forEach(d => {
    const data = d.data();
    if (!data.readBy?.includes(myUid)) {
      batch.push(updateDoc(doc(db, 'chats', chatId, 'messages', d.id), {
        readBy: [...(data.readBy || []), myUid],
      }));
    }
  });
  await Promise.all(batch);
}
