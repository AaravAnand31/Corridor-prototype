// src/services/userService.js
import {
  doc, updateDoc, getDoc, collection,
  query, where, getDocs, arrayUnion, arrayRemove,
  orderBy, limit, serverTimestamp,
} from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage, auth } from './firebase';

const usersCol = () => collection(db, 'users');

// ── Update profile fields ─────────────────────────────────
export async function updateProfile(uid, data) {
  await updateDoc(doc(db, 'users', uid), {
    ...data,
    updatedAt: serverTimestamp(),
  });
}

// ── Upload photo (avatar or cover) ───────────────────────
// type: 'avatar' | 'cover'
export async function uploadPhoto(uid, localUri, type = 'avatar') {
  const resp  = await fetch(localUri);
  const blob  = await resp.blob();
  const path  = `users/${uid}/${type}_${Date.now()}.jpg`;
  const fileRef = ref(storage, path);

  await uploadBytes(fileRef, blob);
  const url = await getDownloadURL(fileRef);

  const field = type === 'avatar' ? 'photoURL' : 'coverURL';
  await updateDoc(doc(db, 'users', uid), { [field]: url });
  return url;
}

// ── Mark profile as complete ──────────────────────────────
export async function markProfileDone(uid) {
  await updateDoc(doc(db, 'users', uid), { profileDone: true });
}

// ── Fetch discover feed ───────────────────────────────────
// Returns profiles excluding: self, already-connected, blocked, blocked-by
export async function fetchDiscoverFeed(currentUser, filters = {}) {
  const meDoc = await getDoc(doc(db, 'users', currentUser.uid));
  const me    = meDoc.data();

  const excluded = new Set([
    currentUser.uid,
    ...(me.connections    || []),
    ...(me.blockedUsers   || []),
    ...(me.blockedByUsers || []),
  ]);

  // Also exclude people who sent requests we already acted on
  const sentSnap = await getDocs(
    query(collection(db, 'connectionRequests'),
      where('fromUid', '==', currentUser.uid))
  );
  sentSnap.forEach(d => excluded.add(d.data().toUid));

  let q = query(usersCol(), where('profileDone', '==', true), limit(50));

  const snap = await getDocs(q);
  let profiles = [];

  snap.forEach(d => {
    const data = d.data();
    if (excluded.has(data.uid)) return;

    // Apply filters
    if (filters.year && filters.year !== 'All' && data.year !== filters.year) return;
    if (filters.lookingFor && filters.lookingFor !== 'All') {
      if (!data.lookingFor?.includes(filters.lookingFor)) return;
    }

    profiles.push(data);
  });

  return profiles;
}

// ── Block / Unblock ───────────────────────────────────────
export async function blockUser(myUid, targetUid) {
  await updateDoc(doc(db, 'users', myUid), {
    blockedUsers: arrayUnion(targetUid),
  });
  // Remove any existing connection
  await updateDoc(doc(db, 'users', myUid), {
    connections: arrayRemove(targetUid),
  });
  await updateDoc(doc(db, 'users', targetUid), {
    connections:  arrayRemove(myUid),
    blockedByUsers: arrayUnion(myUid),
  });
}

export async function unblockUser(myUid, targetUid) {
  await updateDoc(doc(db, 'users', myUid), {
    blockedUsers: arrayRemove(targetUid),
  });
  await updateDoc(doc(db, 'users', targetUid), {
    blockedByUsers: arrayRemove(myUid),
  });
}

export async function fetchBlockedUsers(myUid) {
  const me = await getDoc(doc(db, 'users', myUid));
  const blockedIds = me.data()?.blockedUsers || [];
  if (!blockedIds.length) return [];

  const results = await Promise.all(
    blockedIds.map(uid => getDoc(doc(db, 'users', uid)))
  );
  return results.filter(d => d.exists()).map(d => d.data());
}
