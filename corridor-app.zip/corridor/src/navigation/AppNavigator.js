// src/navigation/AppNavigator.js
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator }    from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Text, View } from 'react-native';
import useStore from '../store/useStore';
import { getTheme } from '../utils/theme';

// Screens
import SplashScreen    from '../screens/SplashScreen';
import LoginScreen     from '../screens/LoginScreen';
import RegisterScreen  from '../screens/RegisterScreen';
import ProfileSetup    from '../screens/ProfileSetupScreen';
import DiscoverScreen  from '../screens/DiscoverScreen';
import ChatsScreen     from '../screens/ChatsScreen';
import ChatRoomScreen  from '../screens/ChatRoomScreen';
import RequestsScreen  from '../screens/RequestsScreen';
import MyProfileScreen from '../screens/MyProfileScreen';
import SettingsScreen  from '../screens/SettingsScreen';
import BlockedScreen   from '../screens/BlockedScreen';

const Stack = createStackNavigator();
const Tab   = createBottomTabNavigator();

function TabIcon({ name, focused, color }) {
  const icons = {
    Discover: '🧭',
    Chats:    '💬',
    Requests: '🔔',
    Profile:  '👤',
  };
  return <Text style={{ fontSize: 22 }}>{icons[name]}</Text>;
}

function MainTabs() {
  const dark    = useStore(s => s.darkMode);
  const theme   = getTheme(dark);
  const pending = useStore(s => s.pendingCount);

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown:     false,
        tabBarShowLabel: true,
        tabBarActiveTintColor:   theme.acc,
        tabBarInactiveTintColor: theme.text3,
        tabBarStyle: {
          backgroundColor: theme.card,
          borderTopColor:  theme.border,
          borderTopWidth:  0.5,
          paddingBottom:   8,
          height:          60,
        },
        tabBarLabelStyle: { fontSize: 10, marginTop: -2 },
        tabBarIcon: ({ focused, color }) => (
          <TabIcon name={route.name} focused={focused} color={color} />
        ),
      })}
    >
      <Tab.Screen name="Discover"  component={DiscoverScreen} />
      <Tab.Screen name="Chats"     component={ChatsScreen} />
      <Tab.Screen
        name="Requests"
        component={RequestsScreen}
        options={{
          tabBarBadge: pending > 0 ? pending : undefined,
          tabBarBadgeStyle: { backgroundColor: '#E24B4A', fontSize: 10 },
        }}
      />
      <Tab.Screen name="Profile"   component={MyProfileScreen} />
    </Tab.Navigator>
  );
}

export default function AppNavigator() {
  const authUser    = useStore(s => s.authUser);
  const authLoading = useStore(s => s.authLoading);
  const userProfile = useStore(s => s.userProfile);

  if (authLoading) return <SplashScreen />;

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {!authUser ? (
          <>
            <Stack.Screen name="Login"    component={LoginScreen} />
            <Stack.Screen name="Register" component={RegisterScreen} />
          </>
        ) : !userProfile?.profileDone ? (
          <Stack.Screen name="ProfileSetup" component={ProfileSetup} />
        ) : (
          <>
            <Stack.Screen name="Main"     component={MainTabs} />
            <Stack.Screen name="ChatRoom" component={ChatRoomScreen} />
            <Stack.Screen name="Settings" component={SettingsScreen} />
            <Stack.Screen name="Blocked"  component={BlockedScreen} />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}
