// src/utils/theme.js
export const COLORS = {
  light: {
    bg1:     '#ffffff',
    bg2:     '#f4f4f0',
    bg3:     '#eeedea',
    text1:   '#111111',
    text2:   '#555555',
    text3:   '#999999',
    border:  'rgba(0,0,0,0.08)',
    border2: 'rgba(0,0,0,0.15)',
    card:    '#ffffff',
    input:   '#f4f4f0',
    acc:     '#3B6D11',
    accBg:   '#EAF3DE',
    accT:    '#27500A',
    accMid:  '#639922',
    danger:  '#E24B4A',
    white:   '#ffffff',
  },
  dark: {
    bg1:     '#0f0f0f',
    bg2:     '#1a1a1a',
    bg3:     '#222222',
    text1:   '#f0f0f0',
    text2:   '#aaaaaa',
    text3:   '#666666',
    border:  'rgba(255,255,255,0.08)',
    border2: 'rgba(255,255,255,0.15)',
    card:    '#1a1a1a',
    input:   '#222222',
    acc:     '#639922',
    accBg:   '#1a2e0a',
    accT:    '#C0DD97',
    accMid:  '#97C459',
    danger:  '#E24B4A',
    white:   '#ffffff',
  },
};

export function getTheme(dark) {
  return dark ? COLORS.dark : COLORS.light;
}

export const TAG_COLORS = {
  'Make friends':     { bg: '#EAF3DE', text: '#27500A' },
  'Project partner':  { bg: '#EAF3DE', text: '#27500A' },
  'Study buddy':      { bg: '#E6F1FB', text: '#0C447C' },
  'Mentor / learn':   { bg: '#FAECE7', text: '#712B13' },
  'Chai & chat':      { bg: '#EAF3DE', text: '#27500A' },
  'Startup ideas':    { bg: '#EEEDFE', text: '#3C3489' },
  default:            { bg: '#EAF3DE', text: '#27500A' },
};

export const YEARS    = ['1st year', '2nd year', '3rd year', 'Final year', 'PG'];
export const LOOKING  = ['Make friends', 'Project partner', 'Study buddy', 'Mentor / learn', 'Chai & chat', 'Startup ideas'];
export const OPEN_TO  = ['Everyone', 'Same year', 'Seniors only', 'Juniors only'];
