// src/screens/BlockedScreen.js
import React, { useEffect, useState } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet, FlatList, ActivityIndicator, Alert } from 'react-native';
import { fetchBlockedUsers, unblockUser } from '../services/userService';
import useStore from '../store/useStore';
import { getTheme } from '../utils/theme';

export default function BlockedScreen({ navigation }) {
  const dark     = useStore(s => s.darkMode);
  const theme    = getTheme(dark);
  const authUser = useStore(s => s.authUser);

  const [blocked,  setBlocked]  = useState([]);
  const [loading,  setLoading]  = useState(true);
  const [unblocking, setUnblocking] = useState(null);

  useEffect(() => {
    fetchBlockedUsers(authUser.uid).then(list => {
      setBlocked(list);
      setLoading(false);
    });
  }, [authUser.uid]);

  async function handleUnblock(uid, name) {
    Alert.alert(`Unblock ${name}?`, 'They\'ll be able to see your profile again.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Unblock', onPress: async () => {
          setUnblocking(uid);
          await unblockUser(authUser.uid, uid);
          setBlocked(prev => prev.filter(u => u.uid !== uid));
          setUnblocking(null);
        },
      },
    ]);
  }

  const s = styles(theme);

  return (
    <View style={s.container}>
      <View style={s.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={{ color: theme.acc, fontSize: 22 }}>←</Text>
        </TouchableOpacity>
        <Text style={s.title}>Blocked users</Text>
        <View style={{ width: 28 }} />
      </View>

      {loading ? (
        <ActivityIndicator color={theme.acc} style={{ flex: 1 }} />
      ) : blocked.length === 0 ? (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: 30 }}>
          <Text style={{ fontSize: 36, marginBottom: 12 }}>🚫</Text>
          <Text style={{ fontSize: 15, fontWeight: '500', color: theme.text1 }}>No blocked users</Text>
          <Text style={{ fontSize: 13, color: theme.text2, marginTop: 6, textAlign: 'center' }}>People you block won't be able to see your profile or contact you.</Text>
        </View>
      ) : (
        <FlatList
          data={blocked}
          keyExtractor={u => u.uid}
          contentContainerStyle={{ padding: 14, gap: 10 }}
          renderItem={({ item: u }) => {
            const initials = u.name?.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase() || '??';
            return (
              <View style={s.card}>
                {u.photoURL
                  ? <Image source={{ uri: u.photoURL }} style={s.av} />
                  : (
                    <View style={[s.av, { backgroundColor: theme.bg2, alignItems: 'center', justifyContent: 'center' }]}>
                      <Text style={{ fontSize: 16, color: theme.text2, fontWeight: '500' }}>{initials}</Text>
                    </View>
                  )
                }
                <View style={{ flex: 1, marginLeft: 12 }}>
                  <Text style={s.name}>{u.name}</Text>
                  <Text style={s.meta}>{u.department} · {u.year}</Text>
                </View>
                <TouchableOpacity
                  style={s.unblockBtn}
                  onPress={() => handleUnblock(u.uid, u.name)}
                  disabled={unblocking === u.uid}
                >
                  {unblocking === u.uid
                    ? <ActivityIndicator color={theme.acc} size="small" />
                    : <Text style={s.unblockT}>Unblock</Text>
                  }
                </TouchableOpacity>
              </View>
            );
          }}
        />
      )}
    </View>
  );
}

const styles = (t) => StyleSheet.create({
  container: { flex: 1, backgroundColor: t.bg1 },
  header:    { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, paddingTop: 52, borderBottomWidth: 0.5, borderColor: t.border },
  title:     { fontSize: 18, fontWeight: '500', color: t.text1 },
  card:      { flexDirection: 'row', alignItems: 'center', backgroundColor: t.card, borderRadius: 12, padding: 12, borderWidth: 0.5, borderColor: t.border },
  av:        { width: 44, height: 44, borderRadius: 22 },
  name:      { fontSize: 14, fontWeight: '500', color: t.text1 },
  meta:      { fontSize: 11, color: t.text2, marginTop: 2 },
  unblockBtn:{ paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20, borderWidth: 0.5, borderColor: t.accMid, backgroundColor: t.accBg },
  unblockT:  { fontSize: 12, color: t.accT, fontWeight: '500' },
});
