// src/screens/DiscoverScreen.js
import React, { useEffect, useState, useCallback } from 'react';
import {
  View, Text, Image, TouchableOpacity, StyleSheet,
  ScrollView, ActivityIndicator, RefreshControl, Alert, Modal,
} from 'react-native';
import { fetchDiscoverFeed } from '../services/userService';
import { sendConnectionRequest } from '../services/connectionService';
import useStore from '../store/useStore';
import { getTheme, LOOKING, YEARS, TAG_COLORS } from '../utils/theme';

function AvatarCircle({ name, photoURL, size = 60, theme }) {
  const initials = name?.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase() || '??';
  if (photoURL) {
    return <Image source={{ uri: photoURL }} style={{ width: size, height: size, borderRadius: size / 2 }} />;
  }
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: theme.accBg, alignItems: 'center', justifyContent: 'center' }}>
      <Text style={{ fontSize: size * 0.34, fontWeight: '500', color: theme.accT }}>{initials}</Text>
    </View>
  );
}

function TagBadge({ label }) {
  const colors = TAG_COLORS[label] || TAG_COLORS.default;
  return (
    <View style={{ backgroundColor: colors.bg, paddingHorizontal: 10, paddingVertical: 3, borderRadius: 20, marginRight: 5, marginBottom: 5 }}>
      <Text style={{ fontSize: 11, color: colors.text, fontWeight: '500' }}>{label}</Text>
    </View>
  );
}

export default function DiscoverScreen() {
  const dark      = useStore(s => s.darkMode);
  const theme     = getTheme(dark);
  const authUser  = useStore(s => s.authUser);
  const filters   = useStore(s => s.filters);
  const setFilters= useStore(s => s.setFilters);

  const [profiles,    setProfiles]    = useState([]);
  const [loading,     setLoading]     = useState(true);
  const [refreshing,  setRefreshing]  = useState(false);
  const [actionLoading, setAction]    = useState(null); // uid being acted on
  const [filterModal, setFilterModal] = useState(false);
  const [skipped,     setSkipped]     = useState(new Set());
  const [connected,   setConnected]   = useState(new Set());

  const load = useCallback(async () => {
    try {
      const feed = await fetchDiscoverFeed(authUser, filters);
      setProfiles(feed);
    } catch (e) {
      Alert.alert('Error', e.message);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [authUser, filters]);

  useEffect(() => { load(); }, [load]);

  async function handleConnect(targetUid) {
    setAction(targetUid);
    try {
      await sendConnectionRequest(authUser.uid, targetUid);
      setConnected(prev => new Set([...prev, targetUid]));
    } catch (e) {
      Alert.alert('Error', e.message);
    } finally {
      setAction(null);
    }
  }

  function handleSkip(uid) {
    setSkipped(prev => new Set([...prev, uid]));
  }

  const visible = profiles.filter(p => !skipped.has(p.uid) && !connected.has(p.uid));
  const s = styles(theme);

  return (
    <View style={s.container}>
      {/* Header */}
      <View style={s.header}>
        <View>
          <Text style={s.title}>Corridor</Text>
          <Text style={s.sub}>Christ University · Ghaziabad</Text>
        </View>
        <TouchableOpacity style={s.filterBtn} onPress={() => setFilterModal(true)}>
          <Text style={{ fontSize: 18 }}>⚙️</Text>
          <Text style={s.filterBtnT}>Filter</Text>
        </TouchableOpacity>
      </View>

      {/* Filter chips */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={s.chipRow} contentContainerStyle={{ paddingHorizontal: 16, gap: 7 }}>
        {['All', ...LOOKING.slice(0, 4)].map(item => (
          <TouchableOpacity
            key={item}
            style={[s.chip, filters.lookingFor === item && s.chipOn]}
            onPress={() => setFilters({ lookingFor: item })}
          >
            <Text style={[s.chipT, filters.lookingFor === item && s.chipTOn]}>{item}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {loading ? (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <ActivityIndicator color={theme.acc} size="large" />
          <Text style={{ color: theme.text3, marginTop: 12, fontSize: 13 }}>Finding people on campus...</Text>
        </View>
      ) : visible.length === 0 ? (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: 30 }}>
          <Text style={{ fontSize: 40, marginBottom: 14 }}>🧭</Text>
          <Text style={{ fontSize: 16, fontWeight: '500', color: theme.text1, textAlign: 'center' }}>You've seen everyone!</Text>
          <Text style={{ fontSize: 13, color: theme.text2, marginTop: 6, textAlign: 'center' }}>Check back tomorrow — new students join every day.</Text>
          <TouchableOpacity style={[s.btnPrimary, { marginTop: 20, paddingHorizontal: 30 }]} onPress={() => { setSkipped(new Set()); load(); }}>
            <Text style={s.btnPrimaryText}>Refresh</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <ScrollView
          contentContainerStyle={{ padding: 14, gap: 14, paddingBottom: 30 }}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load(); }} tintColor={theme.acc} />}
        >
          {visible.map(p => (
            <View key={p.uid} style={s.card}>
              {/* Cover */}
              <View style={[s.cover, { backgroundColor: theme.accBg }]}>
                {p.coverURL ? (
                  <Image source={{ uri: p.coverURL }} style={{ width: '100%', height: '100%' }} resizeMode="cover" />
                ) : null}
                <View style={s.yearBadge}>
                  <Text style={s.yearBadgeT}>{p.year} · {p.department}</Text>
                </View>
              </View>

              {/* Avatar on cover */}
              <View style={s.avatarWrap}>
                <AvatarCircle name={p.name} photoURL={p.photoURL} size={62} theme={theme} />
              </View>

              <View style={s.cardBody}>
                <Text style={s.name}>{p.name}</Text>
                <Text style={s.meta}>{p.department} · {p.year}</Text>

                {/* Tags */}
                <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginTop: 8 }}>
                  {(p.lookingFor || []).map(tag => <TagBadge key={tag} label={tag} />)}
                </View>

                {/* Icebreaker */}
                {p.icebreaker ? (
                  <View style={s.icebreaker}>
                    <Text style={s.icebreakerT}>
                      <Text style={{ fontWeight: '500', color: theme.text1 }}>Icebreaker: </Text>
                      "{p.icebreaker}"
                    </Text>
                  </View>
                ) : p.bio ? (
                  <View style={s.icebreaker}>
                    <Text style={s.icebreakerT}>"{p.bio}"</Text>
                  </View>
                ) : null}

                {/* Interests */}
                {p.interests?.length > 0 && (
                  <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginTop: 6, gap: 4 }}>
                    {p.interests.slice(0, 4).map(i => (
                      <View key={i} style={{ backgroundColor: theme.bg2, paddingHorizontal: 9, paddingVertical: 3, borderRadius: 12 }}>
                        <Text style={{ fontSize: 11, color: theme.text2 }}>{i}</Text>
                      </View>
                    ))}
                  </View>
                )}
              </View>

              {/* Actions */}
              <View style={s.actions}>
                <TouchableOpacity style={s.btnPass} onPress={() => handleSkip(p.uid)}>
                  <Text style={s.btnPassT}>✕  Skip</Text>
                </TouchableOpacity>
                <TouchableOpacity style={s.btnConn} onPress={() => handleConnect(p.uid)} disabled={actionLoading === p.uid}>
                  {actionLoading === p.uid
                    ? <ActivityIndicator color="#fff" size="small" />
                    : <Text style={s.btnConnT}>♡  Connect</Text>
                  }
                </TouchableOpacity>
              </View>
            </View>
          ))}
        </ScrollView>
      )}

      {/* Filter Modal */}
      <Modal visible={filterModal} transparent animationType="slide">
        <TouchableOpacity style={s.modalOverlay} activeOpacity={1} onPress={() => setFilterModal(false)}>
          <View style={s.modalSheet}>
            <Text style={s.modalTitle}>Filter people</Text>

            <Text style={s.label}>Year</Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 14 }}>
              {['All', ...YEARS].map(y => (
                <TouchableOpacity
                  key={y}
                  style={[s.chip, filters.year === y && s.chipOn]}
                  onPress={() => setFilters({ year: y })}
                >
                  <Text style={[s.chipT, filters.year === y && s.chipTOn]}>{y}</Text>
                </TouchableOpacity>
              ))}
            </View>

            <Text style={s.label}>Looking for</Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 24 }}>
              {['All', ...LOOKING].map(l => (
                <TouchableOpacity
                  key={l}
                  style={[s.chip, filters.lookingFor === l && s.chipOn]}
                  onPress={() => setFilters({ lookingFor: l })}
                >
                  <Text style={[s.chipT, filters.lookingFor === l && s.chipTOn]}>{l}</Text>
                </TouchableOpacity>
              ))}
            </View>

            <TouchableOpacity style={s.btnPrimary} onPress={() => { setFilterModal(false); load(); }}>
              <Text style={s.btnPrimaryText}>Apply filters</Text>
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      </Modal>
    </View>
  );
}

const styles = (t) => StyleSheet.create({
  container:   { flex: 1, backgroundColor: t.bg1 },
  header:      { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, paddingTop: 52, borderBottomWidth: 0.5, borderColor: t.border },
  title:       { fontSize: 20, fontWeight: '500', color: t.text1 },
  sub:         { fontSize: 12, color: t.text2, marginTop: 2 },
  filterBtn:   { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: t.bg2, paddingHorizontal: 12, paddingVertical: 7, borderRadius: 20, borderWidth: 0.5, borderColor: t.border2 },
  filterBtnT:  { fontSize: 13, color: t.text2 },
  chipRow:     { maxHeight: 44, marginTop: 8 },
  chip:        { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20, borderWidth: 0.5, borderColor: t.border2, backgroundColor: t.bg2 },
  chipOn:      { backgroundColor: t.accBg, borderColor: t.accMid },
  chipT:       { fontSize: 12, color: t.text2 },
  chipTOn:     { color: t.accT, fontWeight: '500' },
  card:        { backgroundColor: t.card, borderRadius: 14, borderWidth: 0.5, borderColor: t.border, overflow: 'hidden' },
  cover:       { height: 100, width: '100%' },
  yearBadge:   { position: 'absolute', top: 8, right: 10, backgroundColor: t.bg1, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 12, borderWidth: 0.5, borderColor: t.border2 },
  yearBadgeT:  { fontSize: 10, color: t.acc, fontWeight: '500' },
  avatarWrap:  { marginTop: -30, marginLeft: 14, borderWidth: 2, borderColor: t.card, borderRadius: 36, alignSelf: 'flex-start', zIndex: 1 },
  cardBody:    { padding: 12 },
  name:        { fontSize: 16, fontWeight: '500', color: t.text1 },
  meta:        { fontSize: 11, color: t.text2, marginTop: 2 },
  icebreaker:  { marginTop: 10, padding: 10, backgroundColor: t.bg2, borderRadius: 8 },
  icebreakerT: { fontSize: 12, color: t.text2, lineHeight: 18 },
  actions:     { flexDirection: 'row', gap: 8, padding: 12, paddingTop: 4 },
  btnPass:     { flex: 1, padding: 10, borderRadius: 24, borderWidth: 0.5, borderColor: t.border2, backgroundColor: t.bg2, alignItems: 'center' },
  btnPassT:    { fontSize: 13, color: t.text2 },
  btnConn:     { flex: 2, padding: 10, borderRadius: 24, backgroundColor: t.acc, alignItems: 'center' },
  btnConnT:    { fontSize: 13, color: '#fff', fontWeight: '500' },
  modalOverlay:{ flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'flex-end' },
  modalSheet:  { backgroundColor: t.card, borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 22, paddingBottom: 40 },
  modalTitle:  { fontSize: 18, fontWeight: '500', color: t.text1, marginBottom: 18 },
  label:       { fontSize: 12, color: t.text2, fontWeight: '500', marginBottom: 8 },
  btnPrimary:  { backgroundColor: t.acc, borderRadius: 24, padding: 13, alignItems: 'center' },
  btnPrimaryText:{ color: '#fff', fontSize: 14, fontWeight: '500' },
});
