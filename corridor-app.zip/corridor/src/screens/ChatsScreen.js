// src/screens/ChatsScreen.js
import React, { useEffect } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet, FlatList, ActivityIndicator } from 'react-native';
import { listenUserChats } from '../services/chatService';
import useStore from '../store/useStore';
import { getTheme } from '../utils/theme';
import { formatDistanceToNow } from 'date-fns';

function Avatar({ name, photoURL, size = 46, theme }) {
  const initials = name?.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase() || '??';
  if (photoURL) return <Image source={{ uri: photoURL }} style={{ width: size, height: size, borderRadius: size / 2 }} />;
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: theme.accBg, alignItems: 'center', justifyContent: 'center' }}>
      <Text style={{ fontSize: size * 0.34, fontWeight: '500', color: theme.accT }}>{initials}</Text>
    </View>
  );
}

export default function ChatsScreen({ navigation }) {
  const dark     = useStore(s => s.darkMode);
  const theme    = getTheme(dark);
  const authUser = useStore(s => s.authUser);
  const chats    = useStore(s => s.chats);
  const setChats = useStore(s => s.setChats);

  useEffect(() => {
    const unsub = listenUserChats(authUser.uid, setChats);
    return unsub;
  }, [authUser.uid]);

  const s = styles(theme);

  if (!chats) return <ActivityIndicator color={theme.acc} style={{ flex: 1 }} />;

  return (
    <View style={s.container}>
      <View style={s.header}>
        <Text style={s.title}>Chats</Text>
        <Text style={s.sub}>Your connections</Text>
      </View>
      {chats.length === 0 ? (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: 30 }}>
          <Text style={{ fontSize: 40, marginBottom: 14 }}>💬</Text>
          <Text style={{ fontSize: 16, fontWeight: '500', color: theme.text1 }}>No chats yet</Text>
          <Text style={{ fontSize: 13, color: theme.text2, marginTop: 6, textAlign: 'center' }}>Accept a connection request or send one — when both sides connect, chat opens automatically!</Text>
        </View>
      ) : (
        <FlatList
          data={chats}
          keyExtractor={c => c.chatId}
          contentContainerStyle={{ padding: 14, gap: 10 }}
          renderItem={({ item: c }) => {
            const u = c.otherUser;
            const time = c.lastMessageAt?.toDate ? formatDistanceToNow(c.lastMessageAt.toDate(), { addSuffix: true }) : '';
            return (
              <TouchableOpacity
                style={s.chatItem}
                onPress={() => navigation.navigate('ChatRoom', { chatId: c.chatId, otherUser: u })}
              >
                <Avatar name={u.name} photoURL={u.photoURL} size={48} theme={theme} />
                <View style={{ flex: 1, marginLeft: 12 }}>
                  <Text style={s.chatName}>{u.name}</Text>
                  <Text style={s.chatPrev} numberOfLines={1}>{c.lastMessage || 'Say hi 👋'}</Text>
                </View>
                <Text style={s.chatTime}>{time}</Text>
              </TouchableOpacity>
            );
          }}
        />
      )}
    </View>
  );
}

const styles = (t) => StyleSheet.create({
  container: { flex: 1, backgroundColor: t.bg1 },
  header:    { padding: 16, paddingTop: 52, borderBottomWidth: 0.5, borderColor: t.border },
  title:     { fontSize: 20, fontWeight: '500', color: t.text1 },
  sub:       { fontSize: 12, color: t.text2, marginTop: 2 },
  chatItem:  { flexDirection: 'row', alignItems: 'center', backgroundColor: t.card, borderRadius: 12, padding: 12, borderWidth: 0.5, borderColor: t.border },
  chatName:  { fontSize: 14, fontWeight: '500', color: t.text1 },
  chatPrev:  { fontSize: 12, color: t.text2, marginTop: 2 },
  chatTime:  { fontSize: 10, color: t.text3 },
});
