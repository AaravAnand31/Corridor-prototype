// src/screens/SplashScreen.js
import React from 'react';
import { View, Text, ActivityIndicator, StyleSheet } from 'react-native';

export default function SplashScreen() {
  return (
    <View style={s.container}>
      <View style={s.logo}>
        <Text style={{ fontSize: 32 }}>🧭</Text>
      </View>
      <Text style={s.title}>Corridor</Text>
      <Text style={s.sub}>Christ University · Ghaziabad</Text>
      <ActivityIndicator color="#3B6D11" style={{ marginTop: 30 }} />
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#EAF3DE', alignItems: 'center', justifyContent: 'center' },
  logo:      { width: 72, height: 72, borderRadius: 20, backgroundColor: '#3B6D11', alignItems: 'center', justifyContent: 'center', marginBottom: 16 },
  title:     { fontSize: 28, fontWeight: '500', color: '#111' },
  sub:       { fontSize: 13, color: '#555', marginTop: 4 },
});
