// src/screens/RequestsScreen.js
import React, { useEffect, useState } from 'react';
import {
  View, Text, Image, TouchableOpacity, StyleSheet,
  ScrollView, ActivityIndicator, Alert,
} from 'react-native';
import { listenPendingRequests, acceptConnectionRequest, rejectConnectionRequest } from '../services/connectionService';
import useStore from '../store/useStore';
import { getTheme, TAG_COLORS } from '../utils/theme';

function Avatar({ name, photoURL, size = 50, theme }) {
  const initials = name?.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase() || '??';
  if (photoURL) return <Image source={{ uri: photoURL }} style={{ width: size, height: size, borderRadius: size / 2 }} />;
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: theme.accBg, alignItems: 'center', justifyContent: 'center' }}>
      <Text style={{ fontSize: size * 0.34, fontWeight: '500', color: theme.accT }}>{initials}</Text>
    </View>
  );
}

export default function RequestsScreen({ navigation }) {
  const dark     = useStore(s => s.darkMode);
  const theme    = getTheme(dark);
  const authUser = useStore(s => s.authUser);
  const setPending = useStore(s => s.setPendingCount);

  const [requests, setRequests] = useState([]);
  const [loading,  setLoading]  = useState(true);
  const [acting,   setActing]   = useState(null);

  useEffect(() => {
    const unsub = listenPendingRequests(authUser.uid, reqs => {
      setRequests(reqs);
      setPending(reqs.length);
      setLoading(false);
    });
    return unsub;
  }, [authUser.uid]);

  async function handleAccept(req) {
    setActing(req.requestId);
    try {
      const chatId = await acceptConnectionRequest(req.requestId, req.fromUid, req.toUid);
      // Navigate to the new chat
      navigation.navigate('ChatRoom', {
        chatId,
        otherUser: req.fromUser,
      });
    } catch (e) {
      Alert.alert('Error', e.message);
    } finally {
      setActing(null);
    }
  }

  async function handleReject(requestId) {
    setActing(requestId);
    try {
      await rejectConnectionRequest(requestId);
    } catch (e) {
      Alert.alert('Error', e.message);
    } finally {
      setActing(null);
    }
  }

  const s = styles(theme);

  return (
    <View style={s.container}>
      <View style={s.header}>
        <Text style={s.title}>Requests</Text>
        <Text style={s.sub}>{requests.length > 0 ? `${requests.length} pending` : 'No pending requests'}</Text>
      </View>

      {loading ? (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <ActivityIndicator color={theme.acc} size="large" />
        </View>
      ) : requests.length === 0 ? (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: 30 }}>
          <Text style={{ fontSize: 40, marginBottom: 14 }}>🔔</Text>
          <Text style={{ fontSize: 16, fontWeight: '500', color: theme.text1 }}>No requests yet</Text>
          <Text style={{ fontSize: 13, color: theme.text2, marginTop: 6, textAlign: 'center' }}>When someone sends you a connect request, it'll appear here.</Text>
        </View>
      ) : (
        <ScrollView contentContainerStyle={{ padding: 14, gap: 12 }}>
          {requests.map(req => {
            const u = req.fromUser;
            return (
              <View key={req.requestId} style={s.card}>
                <View style={s.cardTop}>
                  <Avatar name={u.name} photoURL={u.photoURL} size={52} theme={theme} />
                  <View style={{ flex: 1, marginLeft: 12 }}>
                    <Text style={s.name}>{u.name}</Text>
                    <Text style={s.meta}>{u.department} · {u.year}</Text>
                    {u.bio ? <Text style={s.bio} numberOfLines={2}>"{u.bio}"</Text> : null}
                  </View>
                </View>

                {/* Tags */}
                <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginTop: 8, marginBottom: 4 }}>
                  {(u.lookingFor || []).map(tag => {
                    const c = TAG_COLORS[tag] || TAG_COLORS.default;
                    return (
                      <View key={tag} style={{ backgroundColor: c.bg, paddingHorizontal: 9, paddingVertical: 3, borderRadius: 20, marginRight: 5, marginBottom: 4 }}>
                        <Text style={{ fontSize: 11, color: c.text, fontWeight: '500' }}>{tag}</Text>
                      </View>
                    );
                  })}
                </View>

                <View style={s.actions}>
                  <TouchableOpacity style={s.btnReject} onPress={() => handleReject(req.requestId)} disabled={acting === req.requestId}>
                    <Text style={s.btnRejectT}>✕  Decline</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={s.btnAccept} onPress={() => handleAccept(req)} disabled={acting === req.requestId}>
                    {acting === req.requestId
                      ? <ActivityIndicator color="#fff" size="small" />
                      : <Text style={s.btnAcceptT}>✓  Accept</Text>
                    }
                  </TouchableOpacity>
                </View>
              </View>
            );
          })}
        </ScrollView>
      )}
    </View>
  );
}

const styles = (t) => StyleSheet.create({
  container: { flex: 1, backgroundColor: t.bg1 },
  header:    { padding: 16, paddingTop: 52, borderBottomWidth: 0.5, borderColor: t.border },
  title:     { fontSize: 20, fontWeight: '500', color: t.text1 },
  sub:       { fontSize: 12, color: t.text2, marginTop: 2 },
  card:      { backgroundColor: t.card, borderRadius: 12, borderWidth: 0.5, borderColor: t.border, padding: 14 },
  cardTop:   { flexDirection: 'row', alignItems: 'flex-start' },
  name:      { fontSize: 15, fontWeight: '500', color: t.text1 },
  meta:      { fontSize: 11, color: t.text2, marginTop: 2 },
  bio:       { fontSize: 12, color: t.text3, marginTop: 4, lineHeight: 17 },
  actions:   { flexDirection: 'row', gap: 10, marginTop: 12 },
  btnReject: { flex: 1, padding: 10, borderRadius: 24, borderWidth: 0.5, borderColor: t.border2, backgroundColor: t.bg2, alignItems: 'center' },
  btnRejectT:{ fontSize: 13, color: t.text2 },
  btnAccept: { flex: 2, padding: 10, borderRadius: 24, backgroundColor: t.acc, alignItems: 'center' },
  btnAcceptT:{ fontSize: 13, color: '#fff', fontWeight: '500' },
});
