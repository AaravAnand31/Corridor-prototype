// src/screens/ProfileSetupScreen.js
import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  ScrollView, Image, ActivityIndicator, Alert,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { updateProfile, uploadPhoto, markProfileDone } from '../services/userService';
import useStore from '../store/useStore';
import { getTheme, LOOKING, YEARS, OPEN_TO } from '../utils/theme';

export default function ProfileSetupScreen() {
  const dark      = useStore(s => s.darkMode);
  const theme     = getTheme(dark);
  const authUser  = useStore(s => s.authUser);
  const profile   = useStore(s => s.userProfile);

  const [bio,        setBio]       = useState('');
  const [lookingFor, setLooking]   = useState([]);
  const [interests,  setInterests] = useState('');
  const [openTo,     setOpenTo]    = useState(['Everyone']);
  const [photoUri,   setPhotoUri]  = useState(null);
  const [coverUri,   setCoverUri]  = useState(null);
  const [icebreaker, setIcebreaker]= useState('');
  const [loading,    setLoading]   = useState(false);
  const [step,       setStep]      = useState(1); // 1 = photos, 2 = about, 3 = preferences

  async function pickImage(type) {
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) {
      Alert.alert('Permission needed', 'Allow photo access to upload your picture.');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: type === 'avatar' ? [1, 1] : [3, 1],
      quality: 0.7,
    });
    if (!result.canceled) {
      type === 'avatar' ? setPhotoUri(result.assets[0].uri) : setCoverUri(result.assets[0].uri);
    }
  }

  function toggleItem(arr, setArr, item) {
    setArr(arr.includes(item) ? arr.filter(i => i !== item) : [...arr, item]);
  }

  async function handleFinish() {
    if (!bio.trim()) {
      Alert.alert('Add a bio', 'Tell others a little about yourself!');
      return;
    }
    if (lookingFor.length === 0) {
      Alert.alert('Pick at least one', 'Select what you\'re looking for.');
      return;
    }
    setLoading(true);
    try {
      const uid = authUser.uid;
      let photoURL = profile?.photoURL || '';
      let coverURL = profile?.coverURL || '';

      if (photoUri) photoURL = await uploadPhoto(uid, photoUri, 'avatar');
      if (coverUri) coverURL = await uploadPhoto(uid, coverUri, 'cover');

      await updateProfile(uid, {
        bio,
        icebreaker,
        lookingFor,
        interests: interests.split(',').map(i => i.trim()).filter(Boolean),
        openTo,
        photoURL,
        coverURL,
        name:       profile?.name,
        year:       profile?.year,
        department: profile?.department,
      });
      await markProfileDone(uid);
    } catch (e) {
      Alert.alert('Error', e.message);
    } finally {
      setLoading(false);
    }
  }

  const s = styles(theme);

  return (
    <ScrollView style={s.container} contentContainerStyle={s.inner} keyboardShouldPersistTaps="handled">
      <Text style={s.title}>Set up your profile</Text>
      <Text style={s.sub}>{profile?.name} · {profile?.year} · {profile?.department}</Text>

      {/* Step dots */}
      <View style={s.steps}>
        {[1,2,3].map(i => (
          <View key={i} style={[s.dot, step >= i && s.dotOn]} />
        ))}
      </View>

      {step === 1 && (
        <View style={s.section}>
          <Text style={s.sectionTitle}>Add your photos</Text>

          {/* Cover */}
          <TouchableOpacity style={s.coverPicker} onPress={() => pickImage('cover')}>
            {coverUri
              ? <Image source={{ uri: coverUri }} style={s.coverImg} />
              : <Text style={s.pickText}>+ Add cover photo (3:1)</Text>
            }
          </TouchableOpacity>

          {/* Avatar */}
          <TouchableOpacity style={s.avatarPicker} onPress={() => pickImage('avatar')}>
            {photoUri
              ? <Image source={{ uri: photoUri }} style={s.avatarImg} />
              : <Text style={{ color: theme.text2, fontSize: 13 }}>+ Profile photo</Text>
            }
          </TouchableOpacity>

          <TouchableOpacity style={s.btnPrimary} onPress={() => setStep(2)}>
            <Text style={s.btnPrimaryText}>Next →</Text>
          </TouchableOpacity>
        </View>
      )}

      {step === 2 && (
        <View style={s.section}>
          <Text style={s.sectionTitle}>Tell people about you</Text>

          <Text style={s.label}>Bio (a few words)</Text>
          <TextInput
            style={[s.input, { height: 80, textAlignVertical: 'top' }]}
            placeholder="e.g. Chess nerd who loves hackathons and late-night coding."
            placeholderTextColor={theme.text3}
            value={bio}
            onChangeText={setBio}
            multiline
            maxLength={160}
          />

          <Text style={s.label}>Icebreaker prompt</Text>
          <TextInput
            style={[s.input, { height: 70, textAlignVertical: 'top' }]}
            placeholder="e.g. The one thing I want to build at college is..."
            placeholderTextColor={theme.text3}
            value={icebreaker}
            onChangeText={setIcebreaker}
            multiline
            maxLength={200}
          />

          <Text style={s.label}>Interests (comma separated)</Text>
          <TextInput
            style={s.input}
            placeholder="e.g. Chess, Coding, Badminton, Music"
            placeholderTextColor={theme.text3}
            value={interests}
            onChangeText={setInterests}
          />

          <View style={s.btnRow}>
            <TouchableOpacity style={s.btnSec} onPress={() => setStep(1)}>
              <Text style={s.btnSecText}>← Back</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[s.btnPrimary, { flex: 2 }]} onPress={() => setStep(3)}>
              <Text style={s.btnPrimaryText}>Next →</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      {step === 3 && (
        <View style={s.section}>
          <Text style={s.sectionTitle}>What are you looking for?</Text>

          <Text style={s.label}>I'm here to (pick all that apply)</Text>
          <View style={s.grid}>
            {LOOKING.map(item => (
              <TouchableOpacity
                key={item}
                style={[s.chip, lookingFor.includes(item) && s.chipOn]}
                onPress={() => toggleItem(lookingFor, setLooking, item)}
              >
                <Text style={[s.chipT, lookingFor.includes(item) && s.chipTOn]}>{item}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <Text style={[s.label, { marginTop: 12 }]}>Show me</Text>
          <View style={s.grid}>
            {OPEN_TO.map(item => (
              <TouchableOpacity
                key={item}
                style={[s.chip, openTo.includes(item) && s.chipOn]}
                onPress={() => toggleItem(openTo, setOpenTo, item)}
              >
                <Text style={[s.chipT, openTo.includes(item) && s.chipTOn]}>{item}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <View style={s.btnRow}>
            <TouchableOpacity style={s.btnSec} onPress={() => setStep(2)}>
              <Text style={s.btnSecText}>← Back</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[s.btnPrimary, { flex: 2 }]} onPress={handleFinish} disabled={loading}>
              {loading
                ? <ActivityIndicator color="#fff" />
                : <Text style={s.btnPrimaryText}>Go to Corridor 🎉</Text>
              }
            </TouchableOpacity>
          </View>
        </View>
      )}
    </ScrollView>
  );
}

const styles = (t) => StyleSheet.create({
  container:     { flex: 1, backgroundColor: t.bg1 },
  inner:         { padding: 24, paddingTop: 56, paddingBottom: 50 },
  title:         { fontSize: 24, fontWeight: '500', color: t.text1 },
  sub:           { fontSize: 13, color: t.text2, marginTop: 4, marginBottom: 16 },
  steps:         { flexDirection: 'row', gap: 8, marginBottom: 24 },
  dot:           { width: 28, height: 4, borderRadius: 2, backgroundColor: t.bg2 },
  dotOn:         { backgroundColor: t.acc },
  section:       { gap: 4 },
  sectionTitle:  { fontSize: 18, fontWeight: '500', color: t.text1, marginBottom: 14 },
  coverPicker:   { height: 110, backgroundColor: t.bg2, borderRadius: 12, alignItems: 'center', justifyContent: 'center', borderWidth: 0.5, borderColor: t.border2, overflow: 'hidden', marginBottom: 12 },
  coverImg:      { width: '100%', height: '100%' },
  pickText:      { color: t.text3, fontSize: 13 },
  avatarPicker:  { width: 80, height: 80, borderRadius: 40, backgroundColor: t.bg2, alignItems: 'center', justifyContent: 'center', borderWidth: 0.5, borderColor: t.border2, overflow: 'hidden', marginBottom: 20, alignSelf: 'center' },
  avatarImg:     { width: 80, height: 80, borderRadius: 40 },
  label:         { fontSize: 12, color: t.text2, fontWeight: '500', marginBottom: 6, marginTop: 8 },
  input:         { borderWidth: 0.5, borderColor: t.border2, borderRadius: 8, padding: 12, fontSize: 13, backgroundColor: t.input, color: t.text1 },
  grid:          { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 4 },
  chip:          { paddingHorizontal: 13, paddingVertical: 8, borderRadius: 20, borderWidth: 0.5, borderColor: t.border2, backgroundColor: t.bg2 },
  chipOn:        { backgroundColor: t.accBg, borderColor: t.accMid },
  chipT:         { fontSize: 12, color: t.text2 },
  chipTOn:       { color: t.accT, fontWeight: '500' },
  btnRow:        { flexDirection: 'row', gap: 10, marginTop: 22 },
  btnPrimary:    { flex: 1, backgroundColor: t.acc, borderRadius: 24, padding: 14, alignItems: 'center' },
  btnPrimaryText:{ color: '#fff', fontSize: 14, fontWeight: '500' },
  btnSec:        { flex: 1, backgroundColor: t.bg2, borderRadius: 24, padding: 14, alignItems: 'center', borderWidth: 0.5, borderColor: t.border2 },
  btnSecText:    { color: t.text1, fontSize: 14 },
});
