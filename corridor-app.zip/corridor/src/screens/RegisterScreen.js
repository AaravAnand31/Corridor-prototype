// src/screens/RegisterScreen.js
import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  KeyboardAvoidingView, Platform, ScrollView, ActivityIndicator, Alert,
} from 'react-native';
import { registerUser } from '../services/authService';
import useStore from '../store/useStore';
import { getTheme } from '../utils/theme';

export default function RegisterScreen({ navigation }) {
  const dark  = useStore(s => s.darkMode);
  const theme = getTheme(dark);

  const [name,     setName]     = useState('');
  const [email,    setEmail]    = useState('');
  const [password, setPassword] = useState('');
  const [confirm,  setConfirm]  = useState('');
  const [year,     setYear]     = useState('');
  const [dept,     setDept]     = useState('');
  const [loading,  setLoading]  = useState(false);

  const years = ['1st year', '2nd year', '3rd year', 'Final year', 'PG'];

  async function handleRegister() {
    if (!name || !email || !password || !year || !dept) {
      Alert.alert('Missing fields', 'Please fill all fields.');
      return;
    }
    if (password !== confirm) {
      Alert.alert('Password mismatch', 'Passwords do not match.');
      return;
    }
    if (password.length < 6) {
      Alert.alert('Weak password', 'Password must be at least 6 characters.');
      return;
    }
    setLoading(true);
    try {
      await registerUser(email, password, { name, year, department: dept });
      Alert.alert('Verify email', 'A verification link has been sent to your college email. Please verify and then log in.');
      navigation.navigate('Login');
    } catch (e) {
      Alert.alert('Registration failed', e.message);
    } finally {
      setLoading(false);
    }
  }

  const s = styles(theme);
  return (
    <KeyboardAvoidingView style={s.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={s.inner} keyboardShouldPersistTaps="handled">
        <TouchableOpacity onPress={() => navigation.goBack()} style={{ marginBottom: 20 }}>
          <Text style={{ color: theme.acc, fontSize: 14 }}>← Back to login</Text>
        </TouchableOpacity>

        <Text style={s.title}>Create account</Text>
        <Text style={s.sub}>Join Corridor · Christ Univ Gzb</Text>

        <View style={s.badge}>
          <Text style={s.badgeText}>🔒 Only @christuniversity.in emails are accepted</Text>
        </View>

        {[
          { label: 'Full name',       value: name,     set: setName,     placeholder: 'e.g. Aarav Anand' },
          { label: 'College email',   value: email,    set: setEmail,    placeholder: 'yourname@christuniversity.in', keyboard: 'email-address' },
          { label: 'Department',      value: dept,     set: setDept,     placeholder: 'e.g. B.Tech CSE, BBA, BCA' },
          { label: 'Password',        value: password, set: setPassword, placeholder: 'Min 6 characters', secure: true },
          { label: 'Confirm password',value: confirm,  set: setConfirm,  placeholder: 'Re-enter password', secure: true },
        ].map(f => (
          <View key={f.label} style={{ marginBottom: 12 }}>
            <Text style={s.label}>{f.label}</Text>
            <TextInput
              style={s.input}
              placeholder={f.placeholder}
              placeholderTextColor={theme.text3}
              value={f.value}
              onChangeText={f.set}
              autoCapitalize="none"
              keyboardType={f.keyboard || 'default'}
              secureTextEntry={f.secure || false}
            />
          </View>
        ))}

        <Text style={s.label}>I am a</Text>
        <View style={s.grid}>
          {years.map(y => (
            <TouchableOpacity
              key={y}
              style={[s.chip, year === y && s.chipOn]}
              onPress={() => setYear(y)}
            >
              <Text style={[s.chipT, year === y && s.chipTOn]}>{y}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <TouchableOpacity style={s.btnPrimary} onPress={handleRegister} disabled={loading}>
          {loading
            ? <ActivityIndicator color="#fff" />
            : <Text style={s.btnPrimaryText}>Create account</Text>
          }
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = (t) => StyleSheet.create({
  container:    { flex: 1, backgroundColor: t.bg1 },
  inner:        { padding: 24, paddingTop: 50, paddingBottom: 40 },
  title:        { fontSize: 24, fontWeight: '500', color: t.text1, marginBottom: 4 },
  sub:          { fontSize: 13, color: t.text2, marginBottom: 20 },
  badge:        { backgroundColor: t.accBg, borderRadius: 8, padding: 10, marginBottom: 20, borderWidth: 0.5, borderColor: t.accMid },
  badgeText:    { fontSize: 12, color: t.accT, fontWeight: '500', textAlign: 'center' },
  label:        { fontSize: 12, color: t.text2, fontWeight: '500', marginBottom: 6 },
  input:        { borderWidth: 0.5, borderColor: t.border2, borderRadius: 8, padding: 12, fontSize: 14, backgroundColor: t.input, color: t.text1 },
  grid:         { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 22, marginTop: 6 },
  chip:         { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, borderWidth: 0.5, borderColor: t.border2, backgroundColor: t.bg2 },
  chipOn:       { backgroundColor: t.accBg, borderColor: t.accMid },
  chipT:        { fontSize: 13, color: t.text2 },
  chipTOn:      { color: t.accT, fontWeight: '500' },
  btnPrimary:   { backgroundColor: t.acc, borderRadius: 24, padding: 14, alignItems: 'center', marginTop: 8 },
  btnPrimaryText:{ color: '#fff', fontSize: 15, fontWeight: '500' },
});
