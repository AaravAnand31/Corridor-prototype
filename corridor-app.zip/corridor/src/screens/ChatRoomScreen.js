// src/screens/ChatRoomScreen.js
import React, { useEffect, useState, useRef } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  FlatList, Image, KeyboardAvoidingView, Platform, ActivityIndicator, Alert,
} from 'react-native';
import { listenMessages, sendMessage, markMessagesRead } from '../services/chatService';
import { blockUser } from '../services/userService';
import useStore from '../store/useStore';
import { getTheme } from '../utils/theme';

export default function ChatRoomScreen({ route, navigation }) {
  const { chatId, otherUser } = route.params;
  const dark     = useStore(s => s.darkMode);
  const theme    = getTheme(dark);
  const authUser = useStore(s => s.authUser);

  const [messages, setMessages] = useState([]);
  const [text,     setText]     = useState('');
  const [sending,  setSending]  = useState(false);
  const listRef = useRef(null);

  useEffect(() => {
    const unsub = listenMessages(chatId, msgs => {
      setMessages(msgs);
      markMessagesRead(chatId, authUser.uid).catch(() => {});
    });
    return unsub;
  }, [chatId]);

  useEffect(() => {
    if (messages.length > 0) {
      listRef.current?.scrollToEnd({ animated: true });
    }
  }, [messages]);

  async function handleSend() {
    const trimmed = text.trim();
    if (!trimmed) return;
    setSending(true);
    setText('');
    try {
      await sendMessage(chatId, authUser.uid, trimmed);
    } catch (e) {
      Alert.alert('Error', e.message);
    } finally {
      setSending(false);
    }
  }

  function handleBlock() {
    Alert.alert(
      `Block ${otherUser.name}?`,
      'They won\'t be able to see your profile or message you. You can unblock them in Settings.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Block', style: 'destructive',
          onPress: async () => {
            await blockUser(authUser.uid, otherUser.uid);
            navigation.goBack();
          },
        },
      ]
    );
  }

  const s = styles(theme);

  const renderMsg = ({ item: msg }) => {
    const isMe = msg.senderUid === authUser.uid;
    const time  = msg.createdAt?.toDate ? msg.createdAt.toDate().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '';
    return (
      <View style={{ alignItems: isMe ? 'flex-end' : 'flex-start', marginBottom: 8 }}>
        <View style={[s.bubble, isMe ? s.bubbleMe : s.bubbleThem]}>
          <Text style={[s.bubbleText, isMe && { color: '#fff' }]}>{msg.text}</Text>
        </View>
        <Text style={[s.msgTime, isMe && { textAlign: 'right' }]}>{time}</Text>
      </View>
    );
  };

  return (
    <KeyboardAvoidingView
      style={s.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 0}
    >
      {/* Header */}
      <View style={s.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={s.back}>
          <Text style={{ color: theme.acc, fontSize: 22 }}>←</Text>
        </TouchableOpacity>
        {otherUser.photoURL
          ? <Image source={{ uri: otherUser.photoURL }} style={s.headerAv} />
          : (
            <View style={[s.headerAv, { backgroundColor: theme.accBg, alignItems: 'center', justifyContent: 'center' }]}>
              <Text style={{ fontSize: 14, fontWeight: '500', color: theme.accT }}>
                {otherUser.name?.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase()}
              </Text>
            </View>
          )
        }
        <View style={{ flex: 1 }}>
          <Text style={s.headerName}>{otherUser.name}</Text>
          <Text style={s.headerSub}>{otherUser.year} · {otherUser.department}</Text>
        </View>
        <TouchableOpacity onPress={handleBlock} style={s.blockBtn}>
          <Text style={{ fontSize: 20 }}>⋯</Text>
        </TouchableOpacity>
      </View>

      {/* Messages */}
      <FlatList
        ref={listRef}
        data={messages}
        keyExtractor={m => m.id}
        contentContainerStyle={{ padding: 14, paddingBottom: 8 }}
        renderItem={renderMsg}
        onContentSizeChange={() => listRef.current?.scrollToEnd({ animated: false })}
      />

      {/* Input bar */}
      <View style={s.inputBar}>
        <TextInput
          style={s.input}
          placeholder="Type a message..."
          placeholderTextColor={theme.text3}
          value={text}
          onChangeText={setText}
          multiline
          maxLength={500}
          onSubmitEditing={handleSend}
        />
        <TouchableOpacity style={[s.sendBtn, !text.trim() && { opacity: 0.4 }]} onPress={handleSend} disabled={!text.trim() || sending}>
          {sending
            ? <ActivityIndicator color="#fff" size="small" />
            : <Text style={{ color: '#fff', fontSize: 16 }}>↑</Text>
          }
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = (t) => StyleSheet.create({
  container:  { flex: 1, backgroundColor: t.bg1 },
  header:     { flexDirection: 'row', alignItems: 'center', padding: 12, paddingTop: 52, borderBottomWidth: 0.5, borderColor: t.border, backgroundColor: t.bg1 },
  back:       { marginRight: 8 },
  headerAv:   { width: 36, height: 36, borderRadius: 18, marginRight: 10 },
  headerName: { fontSize: 14, fontWeight: '500', color: t.text1 },
  headerSub:  { fontSize: 11, color: t.acc, marginTop: 1 },
  blockBtn:   { padding: 6 },
  bubble:     { maxWidth: '75%', padding: 10, borderRadius: 14 },
  bubbleMe:   { backgroundColor: t.acc, borderBottomRightRadius: 3 },
  bubbleThem: { backgroundColor: t.bg2, borderBottomLeftRadius: 3 },
  bubbleText: { fontSize: 13, color: t.text1, lineHeight: 19 },
  msgTime:    { fontSize: 10, color: t.text3, marginTop: 2, marginHorizontal: 2 },
  inputBar:   { flexDirection: 'row', alignItems: 'flex-end', padding: 10, paddingBottom: 24, borderTopWidth: 0.5, borderColor: t.border, backgroundColor: t.bg1, gap: 8 },
  input:      { flex: 1, borderWidth: 0.5, borderColor: t.border2, borderRadius: 18, paddingHorizontal: 14, paddingVertical: 8, fontSize: 13, backgroundColor: t.input, color: t.text1, maxHeight: 100 },
  sendBtn:    { width: 36, height: 36, borderRadius: 18, backgroundColor: t.acc, alignItems: 'center', justifyContent: 'center' },
});
