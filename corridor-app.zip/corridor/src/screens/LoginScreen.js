// src/screens/LoginScreen.js
import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, KeyboardAvoidingView, Platform,
  ScrollView, ActivityIndicator, Alert,
} from 'react-native';
import { loginUser } from '../services/authService';
import useStore from '../store/useStore';
import { getTheme } from '../utils/theme';

export default function LoginScreen({ navigation }) {
  const dark  = useStore(s => s.darkMode);
  const theme = getTheme(dark);

  const [email,    setEmail]    = useState('');
  const [password, setPassword] = useState('');
  const [loading,  setLoading]  = useState(false);

  async function handleLogin() {
    if (!email || !password) {
      Alert.alert('Missing fields', 'Please enter your email and password.');
      return;
    }
    setLoading(true);
    try {
      await loginUser(email, password);
      // AppNavigator will auto-redirect once authUser is set
    } catch (e) {
      Alert.alert('Login failed', e.message);
    } finally {
      setLoading(false);
    }
  }

  const s = styles(theme);
  return (
    <KeyboardAvoidingView
      style={s.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={s.inner} keyboardShouldPersistTaps="handled">
        {/* Logo */}
        <View style={s.logoWrap}>
          <View style={s.logoBg}>
            <Text style={{ fontSize: 28 }}>🧭</Text>
          </View>
          <Text style={s.logoText}>Corridor</Text>
          <Text style={s.logoSub}>Christ (Deemed to be) University · Gzb</Text>
        </View>

        <View style={s.badge}>
          <Text style={s.badgeText}>🔒 Only @christuniversity.in emails allowed</Text>
        </View>

        <View style={s.form}>
          <Text style={s.label}>College email</Text>
          <TextInput
            style={s.input}
            placeholder="yourname@christuniversity.in"
            placeholderTextColor={theme.text3}
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
            keyboardType="email-address"
          />

          <Text style={[s.label, { marginTop: 14 }]}>Password</Text>
          <TextInput
            style={s.input}
            placeholder="Enter password"
            placeholderTextColor={theme.text3}
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />

          <TouchableOpacity style={s.btnPrimary} onPress={handleLogin} disabled={loading}>
            {loading
              ? <ActivityIndicator color="#fff" />
              : <Text style={s.btnPrimaryText}>Sign in</Text>
            }
          </TouchableOpacity>

          <TouchableOpacity style={s.btnSec} onPress={() => navigation.navigate('Register')}>
            <Text style={s.btnSecText}>New here? Create an account</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = (t) => StyleSheet.create({
  container:   { flex: 1, backgroundColor: t.bg1 },
  inner:       { padding: 24, paddingTop: 60 },
  logoWrap:    { alignItems: 'center', marginBottom: 28 },
  logoBg:      { width: 64, height: 64, borderRadius: 18, backgroundColor: t.acc, alignItems: 'center', justifyContent: 'center', marginBottom: 10 },
  logoText:    { fontSize: 26, fontWeight: '500', color: t.text1 },
  logoSub:     { fontSize: 13, color: t.text2, marginTop: 4 },
  badge:       { backgroundColor: t.accBg, borderRadius: 8, padding: 10, marginBottom: 24, borderWidth: 0.5, borderColor: t.accMid },
  badgeText:   { fontSize: 12, color: t.accT, fontWeight: '500', textAlign: 'center' },
  form:        { gap: 4 },
  label:       { fontSize: 12, color: t.text2, fontWeight: '500', marginBottom: 6 },
  input:       { borderWidth: 0.5, borderColor: t.border2, borderRadius: 8, padding: 12, fontSize: 14, backgroundColor: t.input, color: t.text1, marginBottom: 4 },
  btnPrimary:  { backgroundColor: t.acc, borderRadius: 24, padding: 14, alignItems: 'center', marginTop: 18 },
  btnPrimaryText: { color: '#fff', fontSize: 15, fontWeight: '500' },
  btnSec:      { borderRadius: 24, padding: 14, alignItems: 'center', marginTop: 8 },
  btnSecText:  { color: t.acc, fontSize: 14 },
});
