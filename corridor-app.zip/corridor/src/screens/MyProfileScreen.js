// src/screens/MyProfileScreen.js
import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import useStore from '../store/useStore';
import { getTheme, TAG_COLORS } from '../utils/theme';

export default function MyProfileScreen({ navigation }) {
  const dark    = useStore(s => s.darkMode);
  const theme   = getTheme(dark);
  const toggle  = useStore(s => s.toggleDark);
  const profile = useStore(s => s.userProfile);

  const s = styles(theme);
  const p = profile || {};
  const initials = p.name?.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase() || '??';

  return (
    <View style={s.container}>
      <View style={s.header}>
        <Text style={s.title}>Profile</Text>
        <TouchableOpacity style={s.settingsBtn} onPress={() => navigation.navigate('Settings')}>
          <Text style={{ fontSize: 20 }}>⚙️</Text>
        </TouchableOpacity>
      </View>
      <ScrollView contentContainerStyle={{ paddingBottom: 40 }}>
        {/* Cover */}
        <View style={s.cover}>
          {p.coverURL ? <Image source={{ uri: p.coverURL }} style={{ width: '100%', height: '100%' }} resizeMode="cover" /> : null}
        </View>

        {/* Avatar */}
        <View style={s.heroArea}>
          <View style={s.avatarWrap}>
            {p.photoURL
              ? <Image source={{ uri: p.photoURL }} style={s.avatar} />
              : (
                <View style={[s.avatar, { backgroundColor: theme.accBg, alignItems: 'center', justifyContent: 'center' }]}>
                  <Text style={{ fontSize: 26, fontWeight: '500', color: theme.accT }}>{initials}</Text>
                </View>
              )
            }
          </View>
          <View style={{ flex: 1, paddingLeft: 14, paddingTop: 12 }}>
            <Text style={s.name}>{p.name}</Text>
            <Text style={s.meta}>{p.department} · {p.year}</Text>
          </View>
        </View>

        {/* Tags */}
        {p.lookingFor?.length > 0 && (
          <View style={s.section}>
            <Text style={s.sLabel}>Looking for</Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
              {p.lookingFor.map(tag => {
                const c = TAG_COLORS[tag] || TAG_COLORS.default;
                return (
                  <View key={tag} style={{ backgroundColor: c.bg, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20 }}>
                    <Text style={{ fontSize: 12, color: c.text, fontWeight: '500' }}>{tag}</Text>
                  </View>
                );
              })}
            </View>
          </View>
        )}

        {/* Bio */}
        {p.bio ? (
          <View style={s.section}>
            <Text style={s.sLabel}>About</Text>
            <View style={s.block}><Text style={s.blockText}>"{p.bio}"</Text></View>
          </View>
        ) : null}

        {/* Icebreaker */}
        {p.icebreaker ? (
          <View style={s.section}>
            <Text style={s.sLabel}>Icebreaker</Text>
            <View style={s.block}><Text style={s.blockText}>"{p.icebreaker}"</Text></View>
          </View>
        ) : null}

        {/* Interests */}
        {p.interests?.length > 0 && (
          <View style={s.section}>
            <Text style={s.sLabel}>Interests</Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
              {p.interests.map(i => (
                <View key={i} style={{ backgroundColor: theme.bg2, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 }}>
                  <Text style={{ fontSize: 12, color: theme.text2 }}>{i}</Text>
                </View>
              ))}
            </View>
          </View>
        )}

        {/* Stats */}
        <View style={s.section}>
          <Text style={s.sLabel}>Stats</Text>
          <View style={{ flexDirection: 'row', gap: 10 }}>
            {[
              { label: 'Connections', value: p.connections?.length || 0 },
              { label: 'Profile views', value: 0 },
            ].map(stat => (
              <View key={stat.label} style={[s.statCard, { flex: 1 }]}>
                <Text style={s.statNum}>{stat.value}</Text>
                <Text style={s.statLabel}>{stat.label}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Dark mode toggle */}
        <View style={[s.section, { paddingBottom: 0 }]}>
          <TouchableOpacity style={s.toggleRow} onPress={toggle}>
            <Text style={s.toggleLabel}>{dark ? '☀️ Light mode' : '🌙 Dark mode'}</Text>
            <View style={[s.togglePill, { backgroundColor: dark ? theme.acc : theme.bg2 }]}>
              <View style={[s.toggleKnob, { marginLeft: dark ? 18 : 2 }]} />
            </View>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = (t) => StyleSheet.create({
  container:  { flex: 1, backgroundColor: t.bg1 },
  header:     { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, paddingTop: 52 },
  title:      { fontSize: 20, fontWeight: '500', color: t.text1 },
  settingsBtn:{ padding: 4 },
  cover:      { height: 100, backgroundColor: t.accBg },
  heroArea:   { flexDirection: 'row', alignItems: 'flex-end', paddingHorizontal: 16, marginTop: -28 },
  avatarWrap: { borderWidth: 3, borderColor: t.bg1, borderRadius: 38, overflow: 'hidden' },
  avatar:     { width: 72, height: 72, borderRadius: 36 },
  name:       { fontSize: 18, fontWeight: '500', color: t.text1 },
  meta:       { fontSize: 12, color: t.text2, marginTop: 2 },
  section:    { padding: 16, borderBottomWidth: 0.5, borderColor: t.border },
  sLabel:     { fontSize: 10, fontWeight: '500', color: t.text3, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 10 },
  block:      { backgroundColor: t.bg2, borderRadius: 8, padding: 12 },
  blockText:  { fontSize: 13, color: t.text1, lineHeight: 19 },
  statCard:   { backgroundColor: t.bg2, borderRadius: 8, padding: 12, alignItems: 'center' },
  statNum:    { fontSize: 22, fontWeight: '500', color: t.acc },
  statLabel:  { fontSize: 11, color: t.text3, marginTop: 2 },
  toggleRow:  { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  toggleLabel:{ fontSize: 14, color: t.text1 },
  togglePill: { width: 42, height: 24, borderRadius: 12, justifyContent: 'center' },
  toggleKnob: { width: 20, height: 20, borderRadius: 10, backgroundColor: '#fff' },
});
