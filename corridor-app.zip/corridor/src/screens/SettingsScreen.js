// src/screens/SettingsScreen.js
import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, Alert } from 'react-native';
import { logoutUser } from '../services/authService';
import useStore from '../store/useStore';
import { getTheme } from '../utils/theme';

export default function SettingsScreen({ navigation }) {
  const dark    = useStore(s => s.darkMode);
  const theme   = getTheme(dark);
  const toggle  = useStore(s => s.toggleDark);
  const profile = useStore(s => s.userProfile);

  async function handleLogout() {
    Alert.alert('Sign out', 'Are you sure you want to sign out?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Sign out', style: 'destructive', onPress: () => logoutUser() },
    ]);
  }

  const s = styles(theme);
  const rows = [
    { label: 'Blocked users',      icon: '🚫', onPress: () => navigation.navigate('Blocked') },
    { label: 'Edit profile',        icon: '✏️',  onPress: () => Alert.alert('Coming soon', 'Edit profile will be available in next update!') },
    { label: 'Notification settings',icon: '🔔', onPress: () => Alert.alert('Coming soon') },
    { label: dark ? 'Light mode' : 'Dark mode', icon: dark ? '☀️' : '🌙', onPress: toggle },
    { label: 'Privacy policy',      icon: '📋', onPress: () => {} },
    { label: 'About Corridor',      icon: 'ℹ️',  onPress: () => Alert.alert('Corridor v1.0', 'Built for Christ (Deemed to be) University, Ghaziabad.\n\nConnect with your batchmates, seniors, and juniors.') },
  ];

  return (
    <View style={s.container}>
      <View style={s.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={{ color: theme.acc, fontSize: 22 }}>←</Text>
        </TouchableOpacity>
        <Text style={s.title}>Settings</Text>
        <View style={{ width: 28 }} />
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: 40 }}>
        {/* Account info */}
        <View style={s.accountCard}>
          <View style={[s.av, { backgroundColor: theme.accBg }]}>
            <Text style={{ fontSize: 18, fontWeight: '500', color: theme.accT }}>
              {profile?.name?.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase() || '??'}
            </Text>
          </View>
          <View style={{ flex: 1, marginLeft: 12 }}>
            <Text style={s.accName}>{profile?.name}</Text>
            <Text style={s.accEmail}>{profile?.email}</Text>
          </View>
        </View>

        {/* Settings rows */}
        <View style={s.rowGroup}>
          {rows.map((r, i) => (
            <TouchableOpacity key={r.label} style={[s.row, i < rows.length - 1 && s.rowBorder]} onPress={r.onPress}>
              <Text style={s.rowIcon}>{r.icon}</Text>
              <Text style={s.rowLabel}>{r.label}</Text>
              <Text style={{ color: theme.text3, fontSize: 16 }}>›</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Sign out */}
        <TouchableOpacity style={s.signout} onPress={handleLogout}>
          <Text style={s.signoutT}>Sign out</Text>
        </TouchableOpacity>

        <Text style={{ textAlign: 'center', fontSize: 11, color: theme.text3, marginTop: 20 }}>
          Corridor · Christ University Ghaziabad
        </Text>
      </ScrollView>
    </View>
  );
}

const styles = (t) => StyleSheet.create({
  container:   { flex: 1, backgroundColor: t.bg1 },
  header:      { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, paddingTop: 52, borderBottomWidth: 0.5, borderColor: t.border },
  title:       { fontSize: 18, fontWeight: '500', color: t.text1 },
  accountCard: { flexDirection: 'row', alignItems: 'center', margin: 16, backgroundColor: t.card, borderRadius: 12, padding: 14, borderWidth: 0.5, borderColor: t.border },
  av:          { width: 52, height: 52, borderRadius: 26, alignItems: 'center', justifyContent: 'center' },
  accName:     { fontSize: 15, fontWeight: '500', color: t.text1 },
  accEmail:    { fontSize: 12, color: t.text2, marginTop: 2 },
  rowGroup:    { marginHorizontal: 16, backgroundColor: t.card, borderRadius: 12, borderWidth: 0.5, borderColor: t.border, overflow: 'hidden' },
  row:         { flexDirection: 'row', alignItems: 'center', padding: 14, gap: 12 },
  rowBorder:   { borderBottomWidth: 0.5, borderColor: t.border },
  rowIcon:     { fontSize: 18, width: 28 },
  rowLabel:    { flex: 1, fontSize: 14, color: t.text1 },
  signout:     { margin: 16, marginTop: 20, backgroundColor: t.bg2, borderRadius: 24, padding: 14, alignItems: 'center', borderWidth: 0.5, borderColor: '#E24B4A' },
  signoutT:    { color: '#E24B4A', fontSize: 14, fontWeight: '500' },
});
