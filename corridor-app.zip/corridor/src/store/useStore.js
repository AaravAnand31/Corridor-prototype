// src/store/useStore.js
import { create } from 'zustand';

const useStore = create((set, get) => ({
  // ── Auth ───────────────────────────────────────────────
  authUser:    null,   // Firebase auth user object
  userProfile: null,   // Firestore user document
  authLoading: true,

  setAuthUser:    (u)  => set({ authUser: u }),
  setUserProfile: (p)  => set({ userProfile: p }),
  setAuthLoading: (v)  => set({ authLoading: v }),

  // ── Theme ──────────────────────────────────────────────
  darkMode: false,
  toggleDark: () => set(s => ({ darkMode: !s.darkMode })),

  // ── Pending requests count (for badge) ────────────────
  pendingCount: 0,
  setPendingCount: (n) => set({ pendingCount: n }),

  // ── Discover feed ─────────────────────────────────────
  discoverFeed: [],
  setDiscoverFeed: (f) => set({ discoverFeed: f }),

  // ── Chats ─────────────────────────────────────────────
  chats: [],
  setChats: (c) => set({ chats: c }),

  // ── Active filters ────────────────────────────────────
  filters: { year: 'All', lookingFor: 'All' },
  setFilters: (f) => set({ filters: { ...get().filters, ...f } }),
}));

export default useStore;
